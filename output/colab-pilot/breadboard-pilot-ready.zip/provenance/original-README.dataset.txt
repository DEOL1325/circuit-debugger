# Circuit Detection > 1st Train set
https://universe.roboflow.com/bme-electronics/circuit-detection-eoirn

Provided by a Roboflow user
License: CC BY 4.0

